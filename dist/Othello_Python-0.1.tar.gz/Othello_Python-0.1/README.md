# Othello_Python
## Daniel Burns
### A game of Othello written in Python
### No outside dependencies necessary, simply install using pip and run the project from the command line!
